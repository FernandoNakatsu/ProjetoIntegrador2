package projeto;


public class Funcionario {
    private String func1;
    private String func2;
    private String func3;

    public Funcionario (){
        func1 = "Fernando";
        func2 = "Guilherme";
        func3 = "Lucas";
    }
    
}

